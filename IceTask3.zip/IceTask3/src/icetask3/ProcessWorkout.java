package icetask3;

public class ProcessWorkout implements IceTask3.IWorkout {

    private String exercises; 
    private int intensityLevel;
    private int duration;

    public ProcessWorkout(String exercises, int intensityLevel, int duration) {
    this.exercises = exercises;
    this.intensityLevel = intensityLevel;
    this.duration = duration;
    }

    //override for the public interface IWorkout
    @Override
    public String getExercise() { //The get methods
    return exercises;
    }

    
    @Override
    public int getDuration() {
    return duration;
    }

    
    @Override
    public int getIntensityLevel() {
    return intensityLevel;
    }

    @Override
    public void displayWorkout() { //How the workout is displayed
    System.out.println("---------------------------------------");
    System.out.println("Exercises: " + exercises);
    System.out.println("Duration of Exercises: " + duration + " minutes");
    System.out.println("Intensity Level: " + intensityLevel);
    System.out.println("---------------------------------------");
    }
}  

