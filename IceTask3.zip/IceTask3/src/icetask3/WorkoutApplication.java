
package icetask3;
//imports
import java.util.ArrayList;
import java.util.Scanner;


public class WorkoutApplication {
    
    // Method to save a workout
    public static void saveWorkout(ArrayList<ProcessWorkout> workoutList, Scanner scanner) {
    //The user prompts 
    System.out.println("CAPTURE A NEW WORKOUT");
    System.out.println("*************************");
    System.out.print("Enter the exercises: ");
    String exercises = scanner.nextLine();
    System.out.print("Enter the duration (In minutes): ");
    int duration = Integer.parseInt(scanner.nextLine());
    System.out.print("Enter the Intensity Level: ");
    int intensityLevel = Integer.parseInt(scanner.nextLine());

    ProcessWorkout workout = new ProcessWorkout(exercises, intensityLevel, duration);
    workoutList.add(workout);

    System.out.println("Workout details have been successfully saved.");
    }

    // This Method prints all workouts
    public static void printWorkouts(ArrayList<ProcessWorkout> workoutList) {
    if (workoutList.isEmpty()) {
    System.out.println("No workouts available.");
    } else {
    for (ProcessWorkout workout : workoutList) {
    workout.displayWorkout();
    }}}}
