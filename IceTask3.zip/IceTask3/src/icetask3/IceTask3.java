package icetask3;

//imports that link the classes together
import static icetask3.WorkoutApplication.printWorkouts;
import static icetask3.WorkoutApplication.saveWorkout;
import java.util.ArrayList;
import java.util.Scanner;

public class IceTask3 {
    
    //public interface IWorkout
    interface IWorkout{
    String getExercise();      
    int getDuration();        
    int getIntensityLevel();   
    void displayWorkout();     
    }
        
    public static void main(String[] args) {
    ArrayList<ProcessWorkout> workoutList = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    boolean running = true;

    System.out.println("Workout Routine Tracker");
    System.out.println("**************************************");

    while (running) {
    // Menu from previous assignment
    System.out.println("(1) Manage workout routines");
    System.out.println("(2) Exit");
    System.out.print("Select an option: ");
    String menu = scanner.nextLine();

    switch (menu) {
    case "1":
    System.out.println("(1) Capture details of a workout routine");
    System.out.println("(2) Print details of all workout routines");
    System.out.print("Select an option: ");
    String menu2 = scanner.nextLine();

    switch (menu2) {
    case "1":
    saveWorkout(workoutList, scanner);
    break;   
    case "2":
    printWorkouts(workoutList);
    break;

    default:
    System.out.println("Invalid option. Please select 1 or 2.");
    break;   }
    break;

    case "2":
    running = false;
    System.out.println("Exiting the program...");
    break;

    default:
    System.out.println("Invalid option. Please select 1 or 2.");
    break;
    }}
    scanner.close();
    }}